#include <Wire.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// OLED setup
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
Adafruit_MPU6050 mpu;

// ESP32 flex sensor pins
const int flexPins[5] = {32, 33, 34, 35, 25};

int flexRaw[5];
int flexAngle[5];

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);   // ESP32 SDA=21, SCL=22

  // MPU6050 / GY-87 initialization
  if (!mpu.begin()) {
    Serial.println("MPU6050 not found!");
    while (1) delay(10);
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  // OLED initialization
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found!");
    while (1) delay(10);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Gesture Glove Ready");
  display.display();

  delay(1000);
}

void loop() {
  // Read flex sensors
  for (int i = 0; i < 5; i++) {
    flexRaw[i] = analogRead(flexPins[i]);

    // ESP32 ADC range: 0-4095
    flexAngle[i] = map(flexRaw[i], 0, 4095, 0, 180);
    flexAngle[i] = constrain(flexAngle[i], 0, 180);
  }

  // Read MPU6050 from GY-87
  sensors_event_t accel, gyro, temp;
  mpu.getEvent(&accel, &gyro, &temp);

  // OLED display
  display.clearDisplay();
  display.setCursor(0, 0);

  display.println("Flex Angles:");
  display.print("F1:");
  display.print(flexAngle[0]);
  display.print(" F2:");
  display.println(flexAngle[1]);

  display.print("F3:");
  display.print(flexAngle[2]);
  display.print(" F4:");
  display.println(flexAngle[3]);

  display.print("F5:");
  display.println(flexAngle[4]);

  display.println("");

  display.print("AX:");
  display.print(accel.acceleration.x, 1);
  display.print(" AY:");
  display.println(accel.acceleration.y, 1);

  display.print("AZ:");
  display.println(accel.acceleration.z, 1);

  display.print("GX:");
  display.print(gyro.gyro.x, 1);
  display.print(" GY:");
  display.println(gyro.gyro.y, 1);

  display.display();

  // Serial CSV output for future Python/UDP use
  Serial.print(flexAngle[0]);
  Serial.print(",");
  Serial.print(flexAngle[1]);
  Serial.print(",");
  Serial.print(flexAngle[2]);
  Serial.print(",");
  Serial.print(flexAngle[3]);
  Serial.print(",");
  Serial.print(flexAngle[4]);
  Serial.print(",");

  Serial.print(accel.acceleration.x);
  Serial.print(",");
  Serial.print(accel.acceleration.y);
  Serial.print(",");
  Serial.print(accel.acceleration.z);
  Serial.print(",");

  Serial.print(gyro.gyro.x);
  Serial.print(",");
  Serial.print(gyro.gyro.y);
  Serial.print(",");
  Serial.println(gyro.gyro.z);

  delay(100);
}